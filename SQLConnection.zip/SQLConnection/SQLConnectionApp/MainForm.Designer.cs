﻿namespace SQLConnectionTest
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.txtServerName = new System.Windows.Forms.TextBox();
            this.chkAppIntendReadOnly = new System.Windows.Forms.CheckBox();
            this.txtConnectionString = new System.Windows.Forms.TextBox();
            this.chkTrustServerCertificate = new System.Windows.Forms.CheckBox();
            this.cmdTestConn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.grpIntegratedSecurity = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.txtUser = new System.Windows.Forms.TextBox();
            this.chkIntegratedSecurity = new System.Windows.Forms.CheckBox();
            this.grpIntegratedSecurity.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtServerName
            // 
            this.txtServerName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtServerName.Location = new System.Drawing.Point(399, 28);
            this.txtServerName.Name = "txtServerName";
            this.txtServerName.Size = new System.Drawing.Size(619, 31);
            this.txtServerName.TabIndex = 1;
            this.txtServerName.TextChanged += new System.EventHandler(this.GetConnectionString);
            this.txtServerName.LostFocus += new System.EventHandler(this.TextBox_LostFocus);
            // 
            // chkAppIntendReadOnly
            // 
            this.chkAppIntendReadOnly.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chkAppIntendReadOnly.Location = new System.Drawing.Point(18, 314);
            this.chkAppIntendReadOnly.Name = "chkAppIntendReadOnly";
            this.chkAppIntendReadOnly.Size = new System.Drawing.Size(410, 48);
            this.chkAppIntendReadOnly.TabIndex = 8;
            this.chkAppIntendReadOnly.Text = "Application Intent Read-Only";
            this.chkAppIntendReadOnly.UseVisualStyleBackColor = true;
            this.chkAppIntendReadOnly.CheckedChanged += new System.EventHandler(this.GetConnectionString);
            // 
            // txtConnectionString
            // 
            this.txtConnectionString.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtConnectionString.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtConnectionString.Location = new System.Drawing.Point(17, 511);
            this.txtConnectionString.Multiline = true;
            this.txtConnectionString.Name = "txtConnectionString";
            this.txtConnectionString.ReadOnly = true;
            this.txtConnectionString.Size = new System.Drawing.Size(1001, 114);
            this.txtConnectionString.TabIndex = 11;
            // 
            // chkTrustServerCertificate
            // 
            this.chkTrustServerCertificate.CausesValidation = false;
            this.chkTrustServerCertificate.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chkTrustServerCertificate.Checked = true;
            this.chkTrustServerCertificate.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkTrustServerCertificate.Location = new System.Drawing.Point(18, 385);
            this.chkTrustServerCertificate.Name = "chkTrustServerCertificate";
            this.chkTrustServerCertificate.Size = new System.Drawing.Size(410, 48);
            this.chkTrustServerCertificate.TabIndex = 9;
            this.chkTrustServerCertificate.Text = "Trust Server Certificate";
            this.chkTrustServerCertificate.UseVisualStyleBackColor = true;
            this.chkTrustServerCertificate.CheckedChanged += new System.EventHandler(this.GetConnectionString);
            // 
            // cmdTestConn
            // 
            this.cmdTestConn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.cmdTestConn.Location = new System.Drawing.Point(754, 452);
            this.cmdTestConn.Name = "cmdTestConn";
            this.cmdTestConn.Size = new System.Drawing.Size(264, 39);
            this.cmdTestConn.TabIndex = 10;
            this.cmdTestConn.Text = "Check connection";
            this.cmdTestConn.UseVisualStyleBackColor = true;
            this.cmdTestConn.Click += new System.EventHandler(this.TestConn);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(137, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Server Name";
            // 
            // grpIntegratedSecurity
            // 
            this.grpIntegratedSecurity.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.grpIntegratedSecurity.Controls.Add(this.label3);
            this.grpIntegratedSecurity.Controls.Add(this.label2);
            this.grpIntegratedSecurity.Controls.Add(this.txtPassword);
            this.grpIntegratedSecurity.Controls.Add(this.txtUser);
            this.grpIntegratedSecurity.Enabled = false;
            this.grpIntegratedSecurity.Location = new System.Drawing.Point(12, 120);
            this.grpIntegratedSecurity.Name = "grpIntegratedSecurity";
            this.grpIntegratedSecurity.Size = new System.Drawing.Size(1006, 163);
            this.grpIntegratedSecurity.TabIndex = 3;
            this.grpIntegratedSecurity.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(18, 114);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(106, 25);
            this.label3.TabIndex = 6;
            this.label3.Text = "Password";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(18, 52);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 25);
            this.label2.TabIndex = 4;
            this.label2.Text = "User";
            // 
            // txtPassword
            // 
            this.txtPassword.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtPassword.Location = new System.Drawing.Point(387, 108);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.PasswordChar = '*';
            this.txtPassword.Size = new System.Drawing.Size(602, 31);
            this.txtPassword.TabIndex = 7;
            this.txtPassword.Text = "p@$$w0rd";
            this.txtPassword.TextChanged += new System.EventHandler(this.GetConnectionString);
            this.txtPassword.DoubleClick += new System.EventHandler(this.ShowHidePassword);
            this.txtPassword.LostFocus += new System.EventHandler(this.TextBox_LostFocus);
            // 
            // txtUser
            // 
            this.txtUser.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtUser.Location = new System.Drawing.Point(387, 46);
            this.txtUser.Name = "txtUser";
            this.txtUser.Size = new System.Drawing.Size(602, 31);
            this.txtUser.TabIndex = 5;
            this.txtUser.Text = "sa";
            this.txtUser.TextChanged += new System.EventHandler(this.GetConnectionString);
            this.txtUser.LostFocus += new System.EventHandler(this.TextBox_LostFocus);
            // 
            // chkIntegratedSecurity
            // 
            this.chkIntegratedSecurity.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chkIntegratedSecurity.Checked = true;
            this.chkIntegratedSecurity.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkIntegratedSecurity.Location = new System.Drawing.Point(18, 92);
            this.chkIntegratedSecurity.Name = "chkIntegratedSecurity";
            this.chkIntegratedSecurity.Size = new System.Drawing.Size(409, 77);
            this.chkIntegratedSecurity.TabIndex = 2;
            this.chkIntegratedSecurity.Text = "Integrated Security";
            this.chkIntegratedSecurity.UseVisualStyleBackColor = true;
            this.chkIntegratedSecurity.CheckedChanged += new System.EventHandler(this.UseIntegratedSecurity);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1030, 637);
            this.Controls.Add(this.chkIntegratedSecurity);
            this.Controls.Add(this.grpIntegratedSecurity);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cmdTestConn);
            this.Controls.Add(this.chkTrustServerCertificate);
            this.Controls.Add(this.txtConnectionString);
            this.Controls.Add(this.chkAppIntendReadOnly);
            this.Controls.Add(this.txtServerName);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "MainForm";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.Text = "SQL Connection Builder";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.grpIntegratedSecurity.ResumeLayout(false);
            this.grpIntegratedSecurity.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtServerName;
        private System.Windows.Forms.CheckBox chkAppIntendReadOnly;
        private System.Windows.Forms.TextBox txtConnectionString;
        private System.Windows.Forms.CheckBox chkTrustServerCertificate;
        private System.Windows.Forms.Button cmdTestConn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox grpIntegratedSecurity;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.TextBox txtUser;
        private System.Windows.Forms.CheckBox chkIntegratedSecurity;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
    }
}

