﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Linq.Expressions;
using static System.Net.Mime.MediaTypeNames;

namespace SQLConnectionTest
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            txtServerName.Text = Environment.MachineName;

        }

        private string GetConnectionString(Boolean ForceRealPassword)
        {
            SqlConnectionStringBuilder sb = new SqlConnectionStringBuilder { DataSource = txtServerName.Text };

            sb.ApplicationName = this.Text;
            if (chkTrustServerCertificate.Checked) { sb.TrustServerCertificate = true; }
            if (chkAppIntendReadOnly.Checked) { sb.ApplicationIntent = ApplicationIntent.ReadOnly; }
            if (chkIntegratedSecurity.Checked)
            {
                sb.IntegratedSecurity = true;
            }
            else
            {
                sb.UserID = txtUser.Text;
                sb.Password = ForceRealPassword | txtPassword.PasswordChar.Equals(new char()) ? txtPassword.Text : new string(txtPassword.PasswordChar, 8);
            }

            return sb.ConnectionString;
        }

        #region Event

        private void GetConnectionString(object sender, EventArgs e)
        {
            txtConnectionString.Text = GetConnectionString(false);
        }

        private void TextBox_LostFocus(object sender, EventArgs e)
        {
            ((TextBox)sender).Text = ((TextBox)sender).Text.Trim();
        }

        private void UseIntegratedSecurity(object sender, EventArgs e)
        {
            grpIntegratedSecurity.Enabled = !chkIntegratedSecurity.Checked;
            txtPassword.PasswordChar = '*';
            GetConnectionString(sender, e);
        }

        private void ShowHidePassword(object sender, EventArgs e)
        {
            txtPassword.PasswordChar = txtPassword.PasswordChar.Equals(new char()) ? '*' : new char();
            txtPassword.SelectAll();
            GetConnectionString(sender, e);
        }

        private void TestConn(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(GetConnectionString(true));

            try
            {
                Cursor.Current = Cursors.WaitCursor;

                con.Open();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandTimeout = 20;

                string messageboxtext = string.Empty;
                cmd.CommandText = "SELECT @@SERVERNAME";
                messageboxtext += cmd.ExecuteScalar().ToString();
                if (!txtServerName.Text.Equals(messageboxtext)) { messageboxtext = string.Concat(txtServerName.Text, " (", messageboxtext, ")"); }
                messageboxtext += System.Environment.NewLine;
                messageboxtext += System.Environment.NewLine;

                cmd.CommandText = "SELECT @@VERSION";
                messageboxtext += cmd.ExecuteScalar().ToString();


                MessageBox.Show(messageboxtext, string.Concat("Connected to: ", txtServerName.Text), MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)

            {
                MessageBox.Show(ex.Message, string.Concat("Failed to connect to: ", txtServerName.Text), MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                con.Close();
                con.Dispose();
                Cursor.Current = Cursors.Default;
            }
        }
        #endregion Event
    }
}
